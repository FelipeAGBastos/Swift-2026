//
//  ViewController.swift
//  Exemplo POO
//
//  Created by Usuário Convidado on 16/03/26.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtAtleta: UITextField!
    @IBOutlet weak var txtPeso: UITextField!
    @IBOutlet weak var txtAltura: UITextField!
    @IBOutlet weak var txtIMC: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }
    
    

    @IBAction func Calcular(_ sender: Any) {
        let p = Pessoa()
        p.nome = txtAtleta.text
        p.peso = Float(txtPeso.text!)
        p.altura = Float(txtAltura.text!)
        p.calcular()
        txtIMC.text = String(p.imc)
    }
    
    
    

}

